import fitz  # PyMuPDF
from sentence_transformers import SentenceTransformer
import numpy as np
from sqlalchemy import create_engine, Column, Integer, String, Float, ARRAY
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy.exc import IntegrityError
import nltk

# Download the sentence tokenizer
nltk.download('punkt')

# Load the sentence transformer model
sentence_model = SentenceTransformer('all-MiniLM-L6-v2')

# PostgreSQL setup
DATABASE_URL = "postgresql://romit:fruit1@localhost:5432/pdf_repo"
Base = declarative_base()

class VectorTable(Base):
    __tablename__ = 'vectors'
    id = Column(Integer, primary_key=True)
    sentence = Column(String, nullable=False, unique=True)
    vector = Column(ARRAY(Float), nullable=False)

engine = create_engine(DATABASE_URL)
Base.metadata.create_all(engine)
Session = sessionmaker(bind=engine)
session = Session()

def clean_sentence(sentence):
    return sentence.replace('\x00', '')

def add_vectors_to_db(sentences, vectors):
    for sentence, vector in zip(sentences, vectors):
        sentence = clean_sentence(sentence)
        vec = VectorTable(sentence=sentence, vector=vector.tolist())
        try:
            session.add(vec)
            session.commit()
        except IntegrityError:
            session.rollback()

def tokenize_sentences(text):
    sentences = nltk.sent_tokenize(text)
    positions = []
    start = 0
    for sentence in sentences:
        start = text.find(sentence, start)
        end = start + len(sentence)
        positions.append((start, end))
        start = end
    return sentences, positions

def get_sentence_embeddings(sentences):
    embeddings = sentence_model.encode(sentences, convert_to_tensor=True)
    return embeddings.cpu().numpy()

def extract_text_from_pdf(pdf_path):
    document = fitz.open(pdf_path)
    text = ""
    for page in document:
        text += page.get_text()
    return text

if __name__ == "__main__":
    pdf_paths = ["./car.pdf", "./OEE-1.pdf"]
    texts = [extract_text_from_pdf(pdf_path) for pdf_path in pdf_paths]

    all_sentences = []
    all_positions = []
    for text in texts:
        sentences, positions = tokenize_sentences(text)
        all_sentences.extend(sentences)
        all_positions.extend(positions)

    embeddings = get_sentence_embeddings(all_sentences)

    # Add vectors to the database if they do not already exist
    add_vectors_to_db(all_sentences, embeddings)

    print("Data ingestion completed.")

