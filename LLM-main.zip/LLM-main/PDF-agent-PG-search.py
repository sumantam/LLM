from sentence_transformers import SentenceTransformer
import numpy as np
from openai import OpenAI
import requests
import json
from flask import Flask, request, jsonify
from flask_cors import CORS
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
import nltk

GENAI = 'Local'
#GENAI = 'OpenAI'

dia_model = 'llama3:latest' # TODO: update this for whatever model you wish to use
openai_model = 'gpt-3.5-turbo'
OLLAMA_API_URL = 'http://127.0.0.1:11434/api/generate'
OPENAI_API_URL = 'https://api.openai.com/v1/chat/completions'
OPENAI_AUTH = "sk-proj-s9ccox0VxUWGuFu6OttwT3BlbkFJWgM9M9InaymEgEqN9vQi"
OPENAI_ORG = "org-xyk65W28ff2B6DVFPFL5XgoF"
OPENAI_PROJECT = "proj_JzH5245BWBkkeN8JQrUR64jD"

# Download the sentence tokenizer
nltk.download('punkt')

# Load the sentence transformer model
sentence_model = SentenceTransformer('all-MiniLM-L6-v2')

# Set your OpenAI API key
openai_client = OpenAI(
    # This is the default and can be omitted
    api_key=OPENAI_AUTH,
)

app = Flask(__name__)
CORS(app)  # This will enable CORS for all routes

# PostgreSQL setup
DATABASE_URL = "postgresql://romit:fruit1@localhost:5432/pdf_repo"
engine = create_engine(DATABASE_URL)
Session = sessionmaker(bind=engine)
session = Session()

def call_openai_api(model, sys_prompt, user_prompt):
    response = openai_client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": user_prompt}
        ],
        stream=True,
    )

    response_parts = []

    for line in response:
        response_part = line.choices[0].delta.content or ''
        response_parts.append(response_part)

        if 'error' in line:
            raise Exception(line['error'])

        if line.choices[0].finish_reason is not None:
            break

    full_response = ''.join(response_parts)
    return full_response

def call_llama_api(model, sys_prompt, user_prompt):
    r = requests.post(
        OLLAMA_API_URL,
        json={'model': dia_model, 'prompt': user_prompt},
        stream=True
    )
    r.raise_for_status()

    response_parts = []

    for line in r.iter_lines():
        body = json.loads(line)
        response_part = body.get('response', '')
        response_parts.append(response_part)

        if 'error' in body:
            raise Exception(body['error'])

        if body.get('done', False):
            break

    full_response = ''.join(response_parts)
    return full_response

def get_surrounding_texts(text, sentences, positions, indices, num_sentences=1):
    text_chunks = []
    for idx in indices:
        idx = int(idx)  # Ensure idx is an integer
        # Determine the range of sentences to include around the target index
        start_idx = max(idx - num_sentences, 0)
        end_idx = min(idx + num_sentences + 1, len(sentences))

        # Use positions to determine the exact text chunk
        paragraph_start = positions[start_idx][0]
        paragraph_end = positions[end_idx - 1][1]
        text_chunk = text[paragraph_start:paragraph_end]

        text_chunks.append(text_chunk)
    return text_chunks

def get_sentence_embeddings(sentences):
    embeddings = sentence_model.encode(sentences, convert_to_tensor=True)
    return embeddings.cpu().numpy()

def semantic_search(query, top_k=10):
    query_embedding = get_sentence_embeddings([query])[0]
    results = session.execute("SELECT id, sentence, vector FROM vectors").fetchall()
    vectors = np.array([r[2] for r in results])
    sentences = [r[1] for r in results]
    indices = np.argsort(np.linalg.norm(vectors - query_embedding, axis=1))[:top_k]

    # Extract the original text from the database results
    original_text = " ".join(sentences)
    positions = [(r[0], r[0] + len(r[1])) for r in results]

    surrounding_texts = get_surrounding_texts(original_text, sentences, positions, indices)
    return surrounding_texts

def generate_answer(user_prompt, retrieved_texts):
    context = "\n".join(retrieved_texts)
    prompt = f"The original question was: '{user_prompt}'. The context generated from a Vector DB lookup is: '{context}'. Format this result into a human-readable format to answer the original question. Just provide the formatted response, nothing else. Do not add any information not present in the provided context."
    if GENAI == 'Local':
        full_response = call_llama_api(dia_model, "", prompt)
    elif GENAI == 'OpenAI':
        full_response = call_openai_api(openai_model, "", prompt)
    else:
        print("No Gen AI selected. Exiting.")
        exit(1)
    return full_response

#@app.route('/process-pdf', methods=['POST'])
def process_pdf():
    user_prompt = input("Enter your query: ")
    #user_prompt = request.json.get('query')
    top_k = 10
    retrieved_texts = semantic_search(user_prompt, top_k=top_k)
    print("Retrived text: ", retrieved_texts)
    try:
        answer = generate_answer(user_prompt, retrieved_texts)
        print("\n\nGenerated answer: ", answer)
        #return jsonify({'formatted_result': answer})
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    #app.run(debug=True, host='0.0.0.0', port=5002)
    process_pdf()
